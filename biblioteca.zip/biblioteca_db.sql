-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 08-01-2026 a las 01:04:25
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `biblioteca_db`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumnos`
--

CREATE TABLE `alumnos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `grado_salon` varchar(50) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `tiene_deuda` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `alumnos`
--

INSERT INTO `alumnos` (`id`, `nombre`, `grado_salon`, `correo`, `tiene_deuda`) VALUES
(1, 'Juan Pérez', NULL, 'juan.perez@escuela.com', 0),
(2, 'María García', NULL, 'maria.g@escuela.com', 1),
(3, 'Carlos López', NULL, 'carlos.l@escuela.com', 1),
(4, 'Valery Geraldine', '5to A', NULL, 0),
(5, 'Carmen Riveros', '6TO', NULL, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `libros`
--

CREATE TABLE `libros` (
  `id` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `autor` varchar(100) DEFAULT NULL,
  `cantidad_total` int(11) NOT NULL,
  `cantidad_disponible` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `libros`
--

INSERT INTO `libros` (`id`, `titulo`, `autor`, `cantidad_total`, `cantidad_disponible`) VALUES
(1, 'Don Quijote de la Mancha', 'Miguel de Cervantes', 5, 5),
(2, 'Cien años de soledad', 'Gabriel García Márquez', 3, 3),
(3, 'Harry Potter y la piedra filosofal', 'J.K. Rowling', 8, 7),
(4, 'El Principito', 'Antoine de Saint-Exupéry', 10, 10),
(5, 'Rayuela', 'Julio Cortázar', 2, 2),
(6, 'Cien años de soledad', 'Gabriel García Márquez', 15, 15),
(7, 'Don Quijote de la Mancha', 'Miguel de Cervantes', 10, 10),
(8, 'Harry Potter y la piedra filosofal', 'J.K. Rowling', 25, 25),
(9, 'El Principito', 'Antoine de Saint-Exupéry', 30, 30),
(10, 'Rayuela', 'Julio Cortázar', 8, 8),
(11, 'Crónica de una muerte anunciada', 'Gabriel García Márquez', 12, 12),
(12, 'Orgullo y Prejuicio', 'Jane Austen', 10, 10),
(13, '1984', 'George Orwell', 20, 20),
(14, 'El Diario de Ana Frank', 'Ana Frank', 18, 18),
(15, 'La ciudad y los perros', 'Mario Vargas Llosa', 7, 7),
(16, 'El Alquimista', 'Paulo Coelho', 15, 15),
(17, 'Los Miserables', 'Victor Hugo', 5, 5),
(18, 'Matar a un ruiseñor', 'Harper Lee', 10, 10),
(19, 'La Odisea', 'Homero', 12, 11),
(20, 'Cuentos de la Selva', 'Horacio Quiroga', 25, 25),
(21, 'El Hobbit', 'J.R.R. Tolkien', 15, 15),
(22, 'Hamlet', 'William Shakespeare', 10, 10),
(23, 'Metamorfosis', 'Franz Kafka', 14, 14),
(24, 'Pedro Páramo', 'Juan Rulfo', 9, 9),
(25, 'Veinte poemas de amor', 'Pablo Neruda', 20, 20);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prestamos`
--

CREATE TABLE `prestamos` (
  `id` int(11) NOT NULL,
  `id_libro` int(11) DEFAULT NULL,
  `id_alumno` int(11) DEFAULT NULL,
  `fecha_salida` date DEFAULT NULL,
  `fecha_devolucion_esperada` date DEFAULT NULL,
  `estado` enum('pendiente','devuelto') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `prestamos`
--

INSERT INTO `prestamos` (`id`, `id_libro`, `id_alumno`, `fecha_salida`, `fecha_devolucion_esperada`, `estado`) VALUES
(1, 3, 2, '2026-01-08', '2026-01-16', 'pendiente'),
(2, 19, 3, '2026-01-08', '2026-01-31', 'pendiente');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `libros`
--
ALTER TABLE `libros`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `prestamos`
--
ALTER TABLE `prestamos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_libro` (`id_libro`),
  ADD KEY `id_alumno` (`id_alumno`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `alumnos`
--
ALTER TABLE `alumnos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `libros`
--
ALTER TABLE `libros`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `prestamos`
--
ALTER TABLE `prestamos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `prestamos`
--
ALTER TABLE `prestamos`
  ADD CONSTRAINT `prestamos_ibfk_1` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id`),
  ADD CONSTRAINT `prestamos_ibfk_2` FOREIGN KEY (`id_alumno`) REFERENCES `alumnos` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
